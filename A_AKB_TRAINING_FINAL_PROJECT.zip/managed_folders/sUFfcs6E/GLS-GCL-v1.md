---
doc_key: GLS-GCL-v1
doc_id: GLS-GCL
version: 1
title: Group credit limit
content_type: glossary
language: en
status: in_force
valid_from: 2026-01-01
valid_to: 
owner: Credit Risk Data Governance
confidentiality: internal
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate; branch-staff
applies_to_group: 
limit_try_m: 
subjects: group-credit-limit
supersedes: 
derived_from: 
implements: 
---

# Group credit limit

## Definition

Group credit limit (grup kredi limiti): the maximum total exposure the bank accepts for a risk group, set by a credit committee decision.
