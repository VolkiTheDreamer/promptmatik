---
doc_key: FAQ-RM-12-v0
doc_id: FAQ-RM-12
version: 0
title: Does a new loan fit the limit? (old)
content_type: faq
language: en
status: superseded
valid_from: 2025-01-01
valid_to: 2026-04-14
owner: Credit Risk
confidentiality: internal
retrieval_tier: open
access_groups: rm-corporate; branch-staff; credit-risk
applies_to_group: 
limit_try_m: 
subjects: group-credit-limit
supersedes: 
derived_from: 
implements: 
---

# Does a new loan fit the limit? (old)

## Question

Does a new loan fit the limit?

## Answer

Compare the requested amount plus the company's own exposure with the latest committee decision you can find.
