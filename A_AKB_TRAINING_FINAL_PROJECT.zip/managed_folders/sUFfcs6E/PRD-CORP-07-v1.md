---
doc_key: PRD-CORP-07-v1
doc_id: PRD-CORP-07
version: 1
title: Corporate working-capital loan (old)
content_type: product_sheet
language: en
status: superseded
valid_from: 2024-01-01
valid_to: 2026-01-31
owner: Corporate Products
confidentiality: public
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate; branch-staff; public
applies_to_group: 
limit_try_m: 
subjects: working-capital-loan
supersedes: 
derived_from: 
implements: 
---

# Corporate working-capital loan (old)

## Product

Working-capital loans for corporate customers. Every loan is subject to credit approval.
