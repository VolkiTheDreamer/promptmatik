---
doc_key: POL-CR-04-v3
doc_id: POL-CR-04
version: 3
title: Corporate credit policy
content_type: policy
language: en
status: in_force
valid_from: 2026-01-01
valid_to: 
owner: Credit Policy
confidentiality: internal
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate; branch-staff
applies_to_group: 
limit_try_m: 
subjects: risk-group; group-credit-limit; group-exposure; limit-increase
supersedes: POL-CR-04-v2
derived_from: 
implements: 
---

# Corporate credit policy

## §4.1 Scope

This section governs credit to corporate and commercial customers that belong to a risk group.

## §4.2 Group credit limits

Each risk group has a group credit limit set by the credit committee, below the legal limit.

## §4.3 Group exposure

Group exposure includes the cash and non-cash loans of every member of the risk group. Closed loans are excluded.

## §4.4 Requests above the limit

A request that would take group exposure above the group limit requires a limit-increase proposal to the credit committee, following procedure PRC-CR-11.

## §4.5 Unresolved borrowers

If an active loan's borrower is not yet matched to a golden ID and may belong to the group, the group exposure cannot be confirmed until identity resolution is complete (procedure PRC-KYC-03).

## §4.6 Decision in force

Only the committee decision in force on the date of the request applies. If more than one decision appears to be in force for the same group, refer to Credit Risk before any recommendation.
