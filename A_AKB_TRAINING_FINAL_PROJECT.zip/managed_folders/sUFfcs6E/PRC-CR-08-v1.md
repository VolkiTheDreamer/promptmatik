---
doc_key: PRC-CR-08-v1
doc_id: PRC-CR-08
version: 1
title: Grup riski hesaplama prosedürü
content_type: procedure
language: tr
status: in_force
valid_from: 2026-02-01
valid_to: 
owner: Credit Risk
confidentiality: internal
retrieval_tier: open
access_groups: credit-risk; rm-corporate
applies_to_group: 
limit_try_m: 
subjects: group-exposure
supersedes: 
derived_from: 
implements: 
---

# Grup riski hesaplama prosedürü

## Adımlar

1. Risk grubunun güncel üyelerini doğrulayın.
2. Tüm üyelerin aktif nakdi ve gayrinakdi kredilerini toplayın; kapanmış kredileri dahil etmeyin.
3. Borçlusu henüz eşleşmemiş krediler varsa bunları 'beklemede' olarak işaretleyin; grup riski kesinleşene kadar öneri vermeyin (PRC-KYC-03).
