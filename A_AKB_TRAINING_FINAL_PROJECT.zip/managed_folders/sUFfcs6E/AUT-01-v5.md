---
doc_key: AUT-01-v5
doc_id: AUT-01
version: 5
title: Credit authority matrix
content_type: rule_table
language: en
status: in_force
valid_from: 2026-01-01
valid_to: 
owner: Credit Policy
confidentiality: internal
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate
applies_to_group: 
limit_try_m: 
subjects: credit-authority; group-credit-limit
supersedes: 
derived_from: 
implements: 
---

# Credit authority matrix

## Authority

| Situation | Who may do what |
|---|---|
| The request keeps group exposure within the group limit | The credit agent may recommend; the authorised credit officer decides |
| The request takes group exposure above the group limit | The credit agent prepares a limit-increase proposal for the credit committee (PRC-CR-11) |
| Group exposure cannot be confirmed | No recommendation; refer to Credit Risk |
