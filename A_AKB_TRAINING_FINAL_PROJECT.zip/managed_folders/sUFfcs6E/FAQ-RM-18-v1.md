---
doc_key: FAQ-RM-18-v1
doc_id: FAQ-RM-18
version: 1
title: What if a loan's borrower is not matched?
content_type: faq
language: en
status: in_force
valid_from: 2026-04-15
valid_to: 
owner: Credit Risk
confidentiality: internal
retrieval_tier: open
access_groups: rm-corporate; branch-staff; credit-risk
applies_to_group: 
limit_try_m: 
subjects: identity-resolution
supersedes: 
derived_from: POL-CR-04-v3; PRC-KYC-03-v1
implements: 
---

# What if a loan's borrower is not matched?

## Question

What if a loan's borrower is not matched to a golden ID?

## Answer

The group exposure cannot be confirmed while the match is pending. Ask Master Data to resolve it (PRC-KYC-03) before giving a recommendation.
