---
doc_key: FAQ-RM-21-v1
doc_id: FAQ-RM-21
version: 1
title: Limit aşımında kim karar verir?
content_type: faq
language: tr
status: in_force
valid_from: 2026-04-15
valid_to: 
owner: Credit Risk
confidentiality: internal
retrieval_tier: open
access_groups: rm-corporate; branch-staff; credit-risk
applies_to_group: 
limit_try_m: 
subjects: credit-authority
supersedes: 
derived_from: AUT-01-v5
implements: 
---

# Limit aşımında kim karar verir?

## Soru

Grup limiti aşılırsa kim karar verir?

## Cevap

Kredi komitesi karar verir. Kredi asistanı onay veremez; PRC-CR-11 prosedürüne göre limit artırım önerisi hazırlanır.
