---
doc_key: GLS-RG-v2
doc_id: GLS-RG
version: 2
title: Risk group · risk grubu
content_type: glossary
language: en
status: in_force
valid_from: 2026-01-01
valid_to: 
owner: Credit Risk Data Governance
confidentiality: internal
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate; branch-staff
applies_to_group: 
limit_try_m: 
subjects: risk-group
supersedes: 
derived_from: 
implements: 
---

# Risk group · risk grubu

## Definition

Risk group (risk grubu): the head company plus every company it controls, manages or guarantees (teaching version, based on Banking Law 5411 art. 49). Related terms: group credit limit, group exposure.
