---
doc_key: FAQ-RM-15-v1
doc_id: FAQ-RM-15
version: 1
title: Teminat mektupları grup riskine dahil mi?
content_type: faq
language: tr
status: in_force
valid_from: 2026-03-01
valid_to: 
owner: Credit Risk
confidentiality: internal
retrieval_tier: open
access_groups: rm-corporate; branch-staff; credit-risk
applies_to_group: 
limit_try_m: 
subjects: group-exposure
supersedes: 
derived_from: POL-CR-04-v3
implements: 
---

# Teminat mektupları grup riskine dahil mi?

## Soru

Teminat mektupları grup riskine dahil mi?

## Cevap

Evet. Grup riski, risk grubundaki tüm üyelerin nakdi ve gayrinakdi kredilerini içerir; teminat mektupları gayrinakdi kredidir.
