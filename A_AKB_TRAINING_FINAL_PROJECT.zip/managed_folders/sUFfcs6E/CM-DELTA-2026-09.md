---
doc_key: CM-DELTA-2026-09
doc_id: CM-DELTA-2026-09
version: 1
title: Delta risk group credit memo, September 2026
content_type: credit_memo
language: en
status: in_force
valid_from: 2026-09-30
valid_to: 
owner: Credit Risk
confidentiality: highly_confidential
retrieval_tier: restricted
access_groups: credit-committee; credit-risk; rm-delta
applies_to_group: RG-DELTA
limit_try_m: 
subjects: group-exposure; group-credit-limit
supersedes: 
derived_from: 
implements: 
---

# Delta risk group credit memo, September 2026

## Summary

Delta risk group exposure stands at TRY 800 M against a group limit of TRY 1,000 M, leaving headroom of TRY 200 M (as of 2026-09-30).
