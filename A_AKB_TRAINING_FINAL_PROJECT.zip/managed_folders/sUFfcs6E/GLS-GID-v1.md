---
doc_key: GLS-GID-v1
doc_id: GLS-GID
version: 1
title: Golden ID
content_type: glossary
language: en
status: in_force
valid_from: 2025-06-01
valid_to: 
owner: Master Data
confidentiality: internal
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate; branch-staff
applies_to_group: 
limit_try_m: 
subjects: identity-resolution
supersedes: 
derived_from: 
implements: 
---

# Golden ID

## Definition

Golden ID: master data's single identifier for one real-world party across systems (e.g. MDM-300 for Delta Concrete).
