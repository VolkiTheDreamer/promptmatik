---
doc_key: PRC-CR-11-v2
doc_id: PRC-CR-11
version: 2
title: Limit-increase proposal procedure
content_type: procedure
language: en
status: in_force
valid_from: 2026-04-01
valid_to: 
owner: Credit Risk
confidentiality: internal
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate
applies_to_group: 
limit_try_m: 
subjects: limit-increase; credit-authority
supersedes: 
derived_from: 
implements: POL-CR-04-v3; AUT-01-v5
---

# Limit-increase proposal procedure

## Preconditions

The risk group's members and current exposure are confirmed.

## Steps

1. Confirm the risk group's members and current exposure.
2. Add the requested amount and compare with the group limit in force.
3. Complete proposal form CF-07 with the evidence IDs.
4. Submit to the credit committee secretariat.
5. Inform the relationship manager of the submission.

## Exit

If group membership cannot be confirmed, stop and refer to Credit Risk.
