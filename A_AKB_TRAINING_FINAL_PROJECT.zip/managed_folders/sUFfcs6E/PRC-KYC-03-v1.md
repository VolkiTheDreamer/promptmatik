---
doc_key: PRC-KYC-03-v1
doc_id: PRC-KYC-03
version: 1
title: Identity resolution for unmatched loans
content_type: procedure
language: en
status: in_force
valid_from: 2025-09-01
valid_to: 
owner: Master Data
confidentiality: internal
retrieval_tier: open
access_groups: credit-risk; rm-corporate; branch-staff
applies_to_group: 
limit_try_m: 
subjects: identity-resolution; group-exposure
supersedes: 
derived_from: 
implements: 
---

# Identity resolution for unmatched loans

## Procedure

A loan whose borrower is not matched to a golden ID goes to the identity resolution queue. Until a data steward confirms or rejects the candidate match, treat the loan as possibly belonging to the candidate's risk group and do not confirm the group's exposure.
