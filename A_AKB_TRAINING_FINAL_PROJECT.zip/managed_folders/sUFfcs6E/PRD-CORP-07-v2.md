---
doc_key: PRD-CORP-07-v2
doc_id: PRD-CORP-07
version: 2
title: Corporate working-capital loan
content_type: product_sheet
language: en
status: in_force
valid_from: 2026-02-01
valid_to: 
owner: Corporate Products
confidentiality: public
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate; branch-staff; public
applies_to_group: 
limit_try_m: 
subjects: working-capital-loan
supersedes: PRD-CORP-07-v1
derived_from: 
implements: 
---

# Corporate working-capital loan

## Product

Working-capital loans for corporate customers in Turkish lira and foreign currency. Every loan is subject to credit approval and to the customer's group credit limit.
