---
doc_key: PRC-COL-05-v1
doc_id: PRC-COL-05
version: 1
title: Parent-company guarantee procedure
content_type: procedure
language: en
status: in_force
valid_from: 2025-10-01
valid_to: 
owner: Collateral Operations
confidentiality: internal
retrieval_tier: open
access_groups: collateral-ops; credit-risk; rm-corporate; branch-staff
applies_to_group: 
limit_try_m: 
subjects: guarantee; collateral; risk-group
supersedes: 
derived_from: 
implements: 
---

# Parent-company guarantee procedure

## Procedure

A guarantee given by a parent company is recorded in the collateral system and linked to the guaranteed loan. The guarantor and the borrower are reviewed for risk-group membership.
