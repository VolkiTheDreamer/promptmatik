---
doc_key: GLS-EXP-v1
doc_id: GLS-EXP
version: 1
title: Grup riski
content_type: glossary
language: tr
status: in_force
valid_from: 2026-01-01
valid_to: 
owner: Credit Risk Data Governance
confidentiality: internal
retrieval_tier: open
access_groups: credit-committee; credit-risk; rm-corporate; branch-staff
applies_to_group: 
limit_try_m: 
subjects: group-exposure
supersedes: 
derived_from: 
implements: 
---

# Grup riski

## Tanım

Grup riski: bir risk grubundaki tüm üyelerin aktif nakdi ve gayrinakdi kredilerinin toplamı.
