---
doc_key: FAQ-RM-12-v1
doc_id: FAQ-RM-12
version: 1
title: Does a new loan fit the group limit?
content_type: faq
language: en
status: in_force
valid_from: 2026-04-15
valid_to: 
owner: Credit Risk
confidentiality: internal
retrieval_tier: open
access_groups: rm-corporate; branch-staff; credit-risk
applies_to_group: 
limit_try_m: 
subjects: group-credit-limit
supersedes: FAQ-RM-12-v0
derived_from: POL-CR-04-v3; PRC-CR-11-v2
implements: 
---

# Does a new loan fit the group limit?

## Question

Does a new loan fit the customer's group limit?

## Answer

Add the requested amount to the risk group's current exposure and compare the total with the group limit in the credit committee decision in force. If the total is above the limit, follow procedure PRC-CR-11.
