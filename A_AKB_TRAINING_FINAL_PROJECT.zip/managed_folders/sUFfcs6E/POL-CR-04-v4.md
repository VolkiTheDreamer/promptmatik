---
doc_key: POL-CR-04-v4
doc_id: POL-CR-04
version: 4
title: Corporate credit policy (draft revision)
content_type: policy
language: en
status: draft
valid_from: 2027-01-01
valid_to: 
owner: Credit Policy
confidentiality: internal
retrieval_tier: open
access_groups: credit-risk
applies_to_group: 
limit_try_m: 
subjects: risk-group; group-credit-limit
supersedes: POL-CR-04-v3
derived_from: 
implements: 
---

# Corporate credit policy (draft revision)

## §4.2 Group credit limits (proposed)

Each risk group has a group credit limit set by the credit committee, below the legal limit, and reviewed at least every six months.

## §4.4 Requests above the limit (proposed)

Requests up to 10% above the group limit may be approved by the regional credit manager without a committee proposal.
