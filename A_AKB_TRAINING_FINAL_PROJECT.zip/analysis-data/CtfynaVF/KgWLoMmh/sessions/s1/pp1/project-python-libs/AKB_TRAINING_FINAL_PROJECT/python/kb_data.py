"""
kb_data.py
==========
Loads the project's datasets for the agent tools (Dataiku only).

Where it lives in Dataiku
    Project > Libraries > python > kb_data.py   (paste as is)

Data is read on every tool call. The tables are small, and reading fresh data means a
rebuilt membership or a new decision is used immediately (Module 13: no stale copies).
"""

import dataiku
import pandas as pd

import knowledge_rules as kr

# Dataset names used in the Flow (change here if you rename them)
DS = {
    "party": "party",
    "membership": "group_membership",
    "loans": "loan",
    "documents": "documents_metadata",
    "users": "users",
    "identity_candidates": "identity_candidates",
    "risk_group": "risk_group",
    "rule_table": "rule_table",
    "loan_scores": "loan_scores",
}


def _read(name, optional=False):
    try:
        return dataiku.Dataset(name).get_dataframe()
    except Exception:
        if optional:
            return None
        raise


def as_of_default():
    return dataiku.get_custom_variables().get("as_of_date", "2026-11-16")


def load(include_scores=False):
    party = _read(DS["party"])
    loans = _read(DS["loans"])
    loans["borrower_id"] = loans["borrower_id"].where(loans["borrower_id"].notna(), None)
    documents = _read(DS["documents"])
    documents["limit_try_m"] = pd.to_numeric(documents["limit_try_m"], errors="coerce")
    for c in ("valid_from", "valid_to"):
        documents[c] = documents[c].astype(str).replace({"nan": "", "NaT": "", "None": ""})
    risk_group = _read(DS["risk_group"])
    data = {
        "party": party,
        "membership": _read(DS["membership"]),
        "loans": loans,
        "documents": documents,
        "users": _read(DS["users"]),
        "identity_candidates": _read(DS["identity_candidates"]),
        "group_names": dict(zip(risk_group["group_id"], risk_group["group_name"])),
    }
    if include_scores:
        data["loan_scores"] = _read(DS["loan_scores"], optional=True)
    rules = kr.load_rules(_read(DS["rule_table"]))
    return data, rules
