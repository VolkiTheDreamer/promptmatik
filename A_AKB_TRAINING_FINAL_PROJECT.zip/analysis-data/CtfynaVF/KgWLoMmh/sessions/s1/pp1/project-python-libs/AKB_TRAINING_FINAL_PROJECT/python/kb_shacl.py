"""
kb_shacl.py · ADVANCED PATH
===========================
Builds an RDF graph from the knowledge-base metadata and membership and validates it with
SHACL shapes (dss/advanced/shacl_shapes.ttl). Pure Python: needs rdflib and pyshacl.

Where it lives in Dataiku
    Project > Libraries > python > kb_shacl.py   (only for teams on the advanced path)
"""

import pandas as pd
from pyshacl import validate
from rdflib import RDF, Graph, Literal, Namespace, URIRef
from rdflib.namespace import XSD

import knowledge_rules as kr

EX = Namespace("https://example.org/kb/")


def uri(kind, value):
    return URIRef(f"{EX}{kind}/{str(value).replace(' ', '_')}")


def build_graph(documents, membership, party, groups, as_of):
    g = Graph()
    for _, d in documents.iterrows():
        n = uri("doc", d["doc_key"])
        g.add((n, RDF.type, EX.Document))
        if str(d.get("owner", "")).strip():
            g.add((n, EX.owner, Literal(d["owner"])))
        g.add((n, EX.status, Literal(d["status"])))
        vf = kr.to_date(d.get("valid_from"))
        if vf:
            g.add((n, EX.validFrom, Literal(vf.isoformat(), datatype=XSD.date)))
        if kr.active_on(d.get("valid_from"), d.get("valid_to"), as_of):
            g.add((n, EX.validOnAsOf, Literal(True)))
        if d["content_type"] == "decision":
            g.add((n, RDF.type, EX.Decision))
            if pd.notna(d.get("limit_try_m")):
                g.add((n, EX.limitTryM, Literal(str(d["limit_try_m"]), datatype=XSD.decimal)))
            if str(d.get("applies_to_group", "")).strip():
                g.add((n, EX.appliesTo, uri("group", d["applies_to_group"])))
    for _, r in groups.iterrows():
        g.add((uri("group", r["group_id"]), RDF.type, EX.RiskGroup))
    for _, p in party.iterrows():
        g.add((uri("company", p["golden_id"]), RDF.type, EX.Company))
    for _, m in membership.iterrows():
        g.add((uri("company", m["golden_id"]), EX.memberOf, uri("group", m["group_id"])))
    return g


def run(documents, membership, party, groups, shapes_ttl, as_of):
    data_graph = build_graph(documents, membership, party, groups, as_of)
    shapes = Graph().parse(data=shapes_ttl, format="turtle")
    conforms, report_graph, _ = validate(data_graph, shacl_graph=shapes, advanced=True)
    SH = Namespace("http://www.w3.org/ns/shacl#")
    rows = []
    for res in report_graph.subjects(RDF.type, SH.ValidationResult):
        rows.append({
            "focus_node": str(report_graph.value(res, SH.focusNode)).replace(str(EX), ""),
            "message": str(report_graph.value(res, SH.resultMessage)),
            "severity": str(report_graph.value(res, SH.resultSeverity)).split("#")[-1],
        })
    return conforms, pd.DataFrame(rows, columns=["focus_node", "message", "severity"])
