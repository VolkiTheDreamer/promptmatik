"""
kb_pipeline.py
==============
Pure-Python helpers used by the project's code recipes (no Dataiku imports here, so every
function can be tested offline with  python3 test_project.py).

Where it lives in Dataiku
    Project > Libraries > python > kb_pipeline.py   (paste as is)

Functions
    parse_markdown_document()   front matter + body  -> metadata dict
    chunk_document()            one chunk per "## " section, with lineage fields (Module 21)
    build_graph_tables()        node and edge tables for Visual Graph or the Neo4j plugin
    build_loan_features()       features for the early-warning model (baseline + graph features)
    parse_agent_answer()        reads the DECISION / EVIDENCE lines the agent must output
    score_answers()             deterministic evaluation against golden records
"""

from __future__ import annotations

import hashlib
import json
import re

import pandas as pd

import knowledge_rules as kr

META_FIELDS = ["doc_key", "doc_id", "version", "title", "content_type", "language", "status", "valid_from",
               "valid_to", "owner", "confidentiality", "retrieval_tier", "access_groups", "applies_to_group",
               "limit_try_m", "subjects", "supersedes", "derived_from", "implements"]


# --------------------------------------------------------------------------------------
# Documents
# --------------------------------------------------------------------------------------
def parse_markdown_document(text: str, path: str = "") -> dict:
    """Parse the simple 'key: value' front matter used by the generated documents."""
    text = text.replace("\r\n", "\n")
    meta, body = {}, text
    if text.startswith("---\n"):
        end = text.find("\n---\n", 4)
        if end > 0:
            for line in text[4:end].split("\n"):
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = v.strip()
            body = text[end + 5:]
    for f in META_FIELDS:
        meta.setdefault(f, "")
    meta["source_path"] = path
    meta["full_text"] = body.strip()
    return meta


def _slug(s: str) -> str:
    s = kr.turkish_fold(s)
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-")[:40] or "body"


def is_searchable(meta: dict, as_of) -> bool:
    """Open tier, in force and valid on as_of. Restricted content never goes to vector search."""
    return (meta.get("retrieval_tier") == "open" and meta.get("status") == "in_force"
            and kr.active_on(meta.get("valid_from"), meta.get("valid_to"), as_of))


def chunk_document(meta: dict, as_of) -> list[dict]:
    """One chunk per '## ' section. Each chunk carries its context header and lineage (Module 21, B3)."""
    body = meta["full_text"]
    parts = re.split(r"\n(?=## )", "\n" + body)
    chunks = []
    for part in parts:
        part = part.strip()
        if not part or part.startswith("# ") and "\n## " not in part and len(part.split("\n")) == 1:
            continue
        lines = part.split("\n")
        if lines[0].startswith("## "):
            section, content = lines[0][3:].strip(), "\n".join(lines[1:]).strip()
        elif lines[0].startswith("# "):
            continue  # document title line on its own
        else:
            section, content = "Body", part
        if not content:
            continue
        header = f"{meta['title']} | {meta['doc_key']} | {section}"
        text = f"{header}\n\n{content}"
        chunks.append({
            "chunk_id": f"{meta['doc_key']}#{_slug(section)}",
            "doc_key": meta["doc_key"], "doc_id": meta["doc_id"], "version": meta["version"],
            "title": meta["title"], "section": section, "content_type": meta["content_type"],
            "language": meta["language"], "status": meta["status"], "valid_from": meta["valid_from"],
            "valid_to": meta["valid_to"], "retrieval_tier": meta["retrieval_tier"],
            "access_groups": meta["access_groups"], "applies_to_group": meta["applies_to_group"],
            "searchable": "yes" if is_searchable(meta, as_of) else "no",
            "content_hash": hashlib.sha256(text.encode("utf-8")).hexdigest()[:16],
            "text": text,
        })
    return chunks


# --------------------------------------------------------------------------------------
# Graph tables
# --------------------------------------------------------------------------------------
def build_graph_tables(party, groups, ownership, guarantees, loans, membership, as_of) -> dict:
    """Node and edge datasets: company, risk_group; CONTROLS, MEMBER_OF, GUARANTEES (valid on as_of)."""
    nodes_company = party[["golden_id", "name", "segment", "sector"]].copy()
    nodes_group = groups[["group_id", "group_name", "head_id"]].copy()

    ctrl = ownership[ownership["control"].astype(str).str.upper() == "Y"].copy()
    ctrl = ctrl[ctrl.apply(lambda r: kr.active_on(r["valid_from"], r["valid_to"], as_of), axis=1)]
    edges_controls = ctrl.rename(columns={"owner_id": "from_id", "owned_id": "to_id"})[
        ["ownership_id", "from_id", "to_id", "share_pct", "valid_from", "valid_to", "source"]]

    loan_borrower = dict(zip(loans["loan_id"], loans["borrower_id"]))
    g = guarantees[guarantees.apply(lambda r: kr.active_on(r["valid_from"], r["valid_to"], as_of), axis=1)].copy()
    g["to_id"] = g["loan_id"].map(loan_borrower)
    edges_guarantees = g.rename(columns={"guarantor_id": "from_id"})[
        ["guarantee_id", "from_id", "to_id", "loan_id", "amount_try_m", "valid_from", "valid_to", "source"]]

    edges_member_of = membership.rename(columns={"golden_id": "from_id", "group_id": "to_id"})[
        ["from_id", "to_id", "reasons", "depth_from_head", "evidence_ids", "computed_for_date", "rule_version"]]
    edges_member_of["precomputed"] = "yes"
    return {"nodes_company": nodes_company, "nodes_group": nodes_group, "edges_controls": edges_controls,
            "edges_guarantees": edges_guarantees, "edges_member_of": edges_member_of}


# --------------------------------------------------------------------------------------
# Early-warning model features
# --------------------------------------------------------------------------------------
BASELINE_FEATURES = ["product", "cash_noncash", "exposure_try_m", "tenor_months", "days_past_due_max_12m",
                     "borrower_leverage", "sector", "segment"]
GRAPH_FEATURES = ["group_size", "depth_from_head", "guarantees_received", "group_headroom_ratio"]
TARGET = "watchlist_12m"


def build_loan_features(loans, party, membership, guarantees, documents, risk_attrs, outcomes, rules, as_of):
    act = loans[(loans["status"] == "active") & loans["borrower_id"].notna() & (loans["borrower_id"].astype(str) != "")]
    df = act.merge(party[["golden_id", "sector", "segment"]], left_on="borrower_id", right_on="golden_id", how="left")
    df = df.merge(risk_attrs, on="loan_id", how="left")
    df = df.merge(membership[["golden_id", "group_id", "depth_from_head"]], on="golden_id", how="left")
    df["group_size"] = df["group_id"].map(membership.groupby("group_id").size())

    loan_borrower = dict(zip(loans["loan_id"], loans["borrower_id"]))
    received = guarantees.assign(b=guarantees["loan_id"].map(loan_borrower)).groupby("b").size()
    df["guarantees_received"] = df["borrower_id"].map(received).fillna(0).astype(int)

    exposure = act.merge(membership[["golden_id", "group_id"]], left_on="borrower_id", right_on="golden_id") \
                  .groupby("group_id")["exposure_try_m"].sum()

    def limit_for(gid):
        d = kr.decisions_in_force(documents, gid, as_of, rules)
        return float(d.iloc[-1]["limit_try_m"]) if len(d) else float("nan")

    limits = {g: limit_for(g) for g in df["group_id"].dropna().unique()}
    df["group_headroom_ratio"] = df["group_id"].map(lambda g: round(exposure.get(g, 0) / limits[g], 3)
                                                    if limits.get(g) == limits.get(g) and limits.get(g) else 1.0)
    df = df.merge(outcomes, on="loan_id", how="left")
    cols = ["loan_id", "borrower_id", "group_id"] + BASELINE_FEATURES + GRAPH_FEATURES + [TARGET]
    return df[cols]


# --------------------------------------------------------------------------------------
# Deterministic evaluation (works next to the LLM-as-a-judge metrics)
# --------------------------------------------------------------------------------------
_DECISION_RE = re.compile(r"DECISION\s*:\s*([A-Z_]+)", re.IGNORECASE)
_EVIDENCE_RE = re.compile(r"EVIDENCE\s*:\s*(.*)", re.IGNORECASE)
_KEY_RE = re.compile(r"\b(?:DEC-\d{4}-\d{2}|CM-[A-Z0-9-]+-\d{4}-\d{2}|[A-Z]{2,4}-[A-Z]{1,4}-?\d{0,2}-v\d+|[A-Z]{3}-\d{2}-v\d+|REG-5411-49)\b")


def parse_agent_answer(text: str) -> dict:
    text = "" if text is None or (isinstance(text, float) and pd.isna(text)) else str(text)
    m = _DECISION_RE.search(text)
    decision = m.group(1).upper() if m else ""
    ev_line = _EVIDENCE_RE.search(text)
    evidence = set(kr.split_list(ev_line.group(1).replace(",", ";"))) if ev_line else set()
    cited_anywhere = set(_KEY_RE.findall(text))
    return {"decision": decision, "evidence": evidence, "cited_anywhere": cited_anywhere,
            "format_ok": bool(m) and bool(ev_line)}


def _extract_output(raw) -> str:
    """Prompt-recipe outputs are plain text; some setups store JSON. Accept both."""
    if raw is None or (isinstance(raw, float) and pd.isna(raw)):
        return ""
    s = str(raw)
    if s.startswith("{"):
        try:
            obj = json.loads(s)
            for k in ("text", "output", "answer", "llm_output"):
                if k in obj:
                    return str(obj[k])
        except ValueError:
            pass
    return s


def score_answers(golden: pd.DataFrame, answers: pd.DataFrame, answer_col: str = "llm_output") -> tuple:
    """Return (row-level scores, summary). Join key: record_id."""
    df = golden.merge(answers[["record_id", answer_col]], on="record_id", how="left")
    rows = []
    for _, r in df.iterrows():
        parsed = parse_agent_answer(_extract_output(r[answer_col]))
        expected_ev = set(kr.split_list(r.get("expected_evidence", "")))
        forbidden = set(kr.split_list(r.get("forbidden_evidence", "")))
        cited = parsed["evidence"] | parsed["cited_anywhere"]
        recall = (len(expected_ev & cited) / len(expected_ev)) if expected_ev else 1.0
        leak = sorted(forbidden & cited)
        numbers_ok = True
        if isinstance(r.get("expected_numbers"), str) and r["expected_numbers"].strip():
            nums = json.loads(r["expected_numbers"])
            text = _extract_output(r[answer_col]).replace(",", "")
            numbers_ok = all(str(int(round(v))) in text for v in nums.values() if v == v)
        decision_ok = parsed["decision"] == str(r["expected_decision"]).upper()
        rows.append({
            "record_id": r["record_id"], "category": r["category"], "language": r["language"],
            "user_id": r["user_id"], "expected_decision": r["expected_decision"],
            "agent_decision": parsed["decision"], "decision_ok": int(decision_ok),
            "evidence_recall": round(recall, 2), "forbidden_cited": "; ".join(leak), "no_leak": int(not leak),
            "numbers_ok": int(numbers_ok), "format_ok": int(parsed["format_ok"]),
            "passed": int(decision_ok and recall >= 0.99 and not leak and numbers_ok),
        })
    scores = pd.DataFrame(rows)
    summary = pd.DataFrame([{
        "records": len(scores), "passed": int(scores["passed"].sum()),
        "pass_rate": round(scores["passed"].mean(), 3) if len(scores) else 0.0,
        "decision_accuracy": round(scores["decision_ok"].mean(), 3) if len(scores) else 0.0,
        "mean_evidence_recall": round(scores["evidence_recall"].mean(), 3) if len(scores) else 0.0,
        "leaks": int((scores["no_leak"] == 0).sum()), "format_errors": int((scores["format_ok"] == 0).sum()),
    }])
    return scores, summary
