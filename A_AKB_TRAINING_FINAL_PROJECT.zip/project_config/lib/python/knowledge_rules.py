"""
knowledge_rules.py
==================
Rule engine for the "Integrated Knowledge System" final project (Delta, teaching version).

Where it lives in Dataiku
    Project > Libraries > python > knowledge_rules.py   (paste this file as is)

Who uses it
    - recipe  compute_membership.py      (precomputes risk-group membership)
    - tools   tool_check_request.py, tool_get_group_facts.py, tool_get_watchlist_scores.py
    - the data generator (offline), so golden records and the engine always agree

Design principles (from Modules 01, 05, 06, 13, 21)
    - The LLM proposes and explains; this engine decides (deterministic, explainable).
    - "Which decision is in force for group X on date D" is a filter question, not a
      similarity question: decisions are read from document metadata, never from vectors.
    - Unknown is not no: a missing or conflicting fact gives CANNOT_CONFIRM.
    - Access comes from the user's groups, never from the question text.

Everything is fictional teaching material. The risk-group rule is a TEACHING VERSION
inspired by Banking Law 5411 art. 49; it is not the legal definition.
"""

from __future__ import annotations

import datetime as _dt
import json
import re
import unicodedata

import pandas as pd

RULE_VERSION = "teaching-v1"

DECISION_LABELS = (
    "PROPOSAL_REQUIRED",   # request takes group exposure above the limit in force
    "WITHIN_LIMIT",        # request stays within the limit; an authorised officer decides
    "CANNOT_CONFIRM",      # a needed fact is missing, unresolved or conflicting
    "NOT_PERMITTED",       # the user may not see this group's limit and exposure
    "UNKNOWN_COMPANY",     # the company could not be identified
)

STAFF_GROUPS_ALLOWED_TO_SEE_STRUCTURE = {"rm-corporate", "credit-risk", "credit-committee"}
POLICY_KEY = "POL-CR-04-v3"
AUTHORITY_KEY = "AUT-01-v5"
PROPOSAL_PROCEDURE_KEY = "PRC-CR-11-v2"
IDENTITY_PROCEDURE_KEY = "PRC-KYC-03-v1"


# --------------------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------------------
def to_date(value):
    """Parse 'YYYY-MM-DD' (or a date/Timestamp) into a date. Empty -> None."""
    if value is None:
        return None
    if isinstance(value, float) and pd.isna(value):
        return None
    if isinstance(value, _dt.datetime):
        return value.date()
    if isinstance(value, _dt.date):
        return value
    s = str(value).strip()
    if not s or s.lower() in ("nan", "none", "null"):
        return None
    return _dt.date.fromisoformat(s[:10])


def active_on(valid_from, valid_to, as_of) -> bool:
    """True when as_of lies inside [valid_from, valid_to] (open end allowed)."""
    d_from, d_to, d = to_date(valid_from), to_date(valid_to), to_date(as_of)
    if d is None:
        raise ValueError("as_of date is required")
    if d_from is not None and d < d_from:
        return False
    if d_to is not None and d > d_to:
        return False
    return True


def split_list(value) -> list:
    """'a;b; c' -> ['a','b','c'] ; lists pass through; empty -> []."""
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(v).strip() for v in value if str(v).strip()]
    if isinstance(value, float) and pd.isna(value):
        return []
    return [p.strip() for p in str(value).split(";") if p.strip()]


_TR_FOLD = str.maketrans({"ı": "i", "ş": "s", "ğ": "g", "ü": "u", "ö": "o", "ç": "c", "â": "a", "î": "i", "û": "u"})
_LEGAL_SUFFIXES = re.compile(r"\b(a\s*s|ltd|sti|san|tic|inc|plc)\b\.?", re.IGNORECASE)


def turkish_fold(text: str) -> str:
    """Turkish-aware normalisation for name matching.

    Python's str.lower() is NOT Turkish-aware: 'I'.lower() == 'i' (Turkish expects 'ı')
    and 'İ'.lower() == 'i' + combining dot. We map the Turkish capitals explicitly first,
    then lower-case, strip accents, drop legal suffixes and punctuation (Module 21, B5).
    """
    if text is None:
        return ""
    s = str(text).replace("I", "ı").replace("İ", "i").lower()
    s = s.translate(_TR_FOLD)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"[^\w\s]", " ", s)
    s = _LEGAL_SUFFIXES.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


def group_slug(group_id: str) -> str:
    """RG-DELTA -> delta ; RG-07 -> rg07 (used in access groups such as rm-delta)."""
    gid = str(group_id).upper()
    if gid == "RG-DELTA":
        return "delta"
    return gid.replace("-", "").lower()


def allowed_groups_for(group_id: str) -> set:
    return {"credit-committee", "credit-risk", f"rm-{group_slug(group_id)}"}


def fmt_m(x) -> str:
    """Format a TRY-million amount as 'TRY 1,100 M'."""
    return f"TRY {int(round(float(x))):,} M"


# --------------------------------------------------------------------------------------
# Rule table (a Dataiku dataset: rule_key, rule_value, description)
# --------------------------------------------------------------------------------------
DEFAULT_RULES = {
    # membership (teaching version of the risk-group rule)
    "membership_include_control": "true",
    "membership_include_management": "true",
    "membership_include_guarantee": "true",
    # limit checks: left EMPTY in the scaffold on purpose; learners complete them
    "decision_validity_check": "",      # set in rule_table (task R3)
    "multiple_decisions_policy": "",    # set in rule_table (task R3)
    "unresolved_loan_policy": "",       # set in rule_table (task R3)
}


def load_rules(rule_df: pd.DataFrame | None) -> dict:
    rules = dict(DEFAULT_RULES)
    if rule_df is not None and len(rule_df):
        for _, row in rule_df.iterrows():
            key = str(row.get("rule_key", "")).strip()
            if key:
                val = row.get("rule_value", "")
                rules[key] = "" if (val is None or (isinstance(val, float) and pd.isna(val))) else str(val).strip()
    return rules


def _true(rules: dict, key: str) -> bool:
    return str(rules.get(key, "")).strip().lower() in ("true", "yes", "1", "y")


# --------------------------------------------------------------------------------------
# Membership (graph reasoning): head + every company it controls (directly or through a
# company it controls), manages or guarantees  -- TEACHING VERSION
# --------------------------------------------------------------------------------------
def compute_membership(groups: pd.DataFrame, ownership: pd.DataFrame, management: pd.DataFrame,
                       guarantees: pd.DataFrame, loans: pd.DataFrame, rules: dict, as_of) -> pd.DataFrame:
    """Return one row per (company, group) with reasons, depth and evidence ids."""
    as_of = to_date(as_of)

    # control edges valid on as_of
    ctrl = ownership[(ownership["control"].astype(str).str.upper() == "Y")].copy()
    ctrl = ctrl[ctrl.apply(lambda r: active_on(r["valid_from"], r["valid_to"], as_of), axis=1)]
    children = {}
    for _, r in ctrl.iterrows():
        children.setdefault(r["owner_id"], []).append((r["owned_id"], r["ownership_id"]))

    mgmt = management[management.apply(lambda r: active_on(r["valid_from"], r["valid_to"], as_of), axis=1)]
    gtee = guarantees[guarantees.apply(lambda r: active_on(r["valid_from"], r["valid_to"], as_of), axis=1)]
    loan_borrower = dict(zip(loans["loan_id"], loans["borrower_id"]))

    rows = []
    for _, g in groups.iterrows():
        gid, head = g["group_id"], g["head_id"]
        found = {head: {"reasons": ["head"], "depth": 0, "evidence": [g.get("head_source", "") or "risk_group register"]}}

        def add(company, reason, depth, evidence):
            if not isinstance(company, str) or not company:
                return
            entry = found.setdefault(company, {"reasons": [], "depth": depth, "evidence": []})
            if reason not in entry["reasons"]:
                entry["reasons"].append(reason)
            entry["depth"] = min(entry["depth"], depth)
            if evidence and evidence not in entry["evidence"]:
                entry["evidence"].append(evidence)

        if _true(rules, "membership_include_control"):
            queue = [(head, 0, None)]
            seen = {head}
            while queue:
                node, depth, via = queue.pop(0)
                for child, edge_id in children.get(node, []):
                    reason = "control" if node == head else f"control via {node}"
                    add(child, reason, depth + 1, edge_id)
                    if child not in seen:
                        seen.add(child)
                        queue.append((child, depth + 1, node))

        if _true(rules, "membership_include_management"):
            for _, m in mgmt[mgmt["manager_id"] == head].iterrows():
                add(m["managed_id"], "management", 1, m["management_id"])

        if _true(rules, "membership_include_guarantee"):
            for _, q in gtee[gtee["guarantor_id"] == head].iterrows():
                borrower = loan_borrower.get(q["loan_id"])
                add(borrower, f"guarantee {q['guarantee_id']}", 1, q["guarantee_id"])

        for company, info in found.items():
            rows.append({
                "golden_id": company,
                "group_id": gid,
                "reasons": "; ".join(info["reasons"]),
                "depth_from_head": info["depth"],
                "evidence_ids": "; ".join([e for e in info["evidence"] if e]),
                "computed_for_date": as_of.isoformat(),
                "rule_version": RULE_VERSION,
            })
    return pd.DataFrame(rows, columns=["golden_id", "group_id", "reasons", "depth_from_head",
                                       "evidence_ids", "computed_for_date", "rule_version"])


# --------------------------------------------------------------------------------------
# Company resolution
# --------------------------------------------------------------------------------------
def resolve_company(query: str, party: pd.DataFrame):
    """Return (golden_id, name) or (None, None). Accepts a golden ID or a (Turkish) name."""
    if query is None or not str(query).strip():
        return None, None
    q = str(query).strip()
    by_id = party[party["golden_id"].str.upper() == q.upper()]
    if len(by_id) == 1:
        return by_id.iloc[0]["golden_id"], by_id.iloc[0]["name"]
    fq = turkish_fold(q)
    folded = party["name"].map(turkish_fold)
    exact = party[folded == fq]
    if len(exact) == 1:
        return exact.iloc[0]["golden_id"], exact.iloc[0]["name"]
    contains = party[folded.map(lambda n: bool(fq) and (fq in n or n in fq))]
    if len(contains) == 1:
        return contains.iloc[0]["golden_id"], contains.iloc[0]["name"]
    return None, None


# --------------------------------------------------------------------------------------
# Decisions in force (a KB metadata question, not a vector question)
# --------------------------------------------------------------------------------------
def decisions_in_force(documents: pd.DataFrame, group_id: str, as_of, rules: dict) -> pd.DataFrame:
    d = documents[(documents["content_type"] == "decision") & (documents["applies_to_group"] == group_id)].copy()
    d = d[~d["status"].isin(["superseded", "draft", "withdrawn"])]
    if str(rules.get("decision_validity_check", "")).lower() == "dates":
        d = d[d.apply(lambda r: active_on(r["valid_from"], r["valid_to"], as_of), axis=1)]
    else:
        # naive scaffold behaviour: trusts the status field and ignores validity dates
        d = d[d["valid_from"].map(lambda v: to_date(v) is None or to_date(v) <= to_date(as_of))]
    return d.sort_values("valid_from")


# --------------------------------------------------------------------------------------
# The main decision: may we give company X a new loan of A (TRY M) on date D, for user U?
# --------------------------------------------------------------------------------------
def check_request(company_query: str, amount_try_m: float, as_of, user_id: str, data: dict, rules: dict) -> dict:
    """data keys: party, membership, loans, documents, users, identity_candidates (DataFrames)."""
    party, membership, loans = data["party"], data["membership"], data["loans"]
    documents, users, candidates = data["documents"], data["users"], data["identity_candidates"]
    as_of = to_date(as_of)
    amount = float(amount_try_m)
    out = {"decision": None, "company_query": company_query, "amount_try_m": amount,
           "as_of": as_of.isoformat(), "user_id": user_id, "golden_id": None, "company_name": None,
           "group_id": None, "group_name": None, "members": [], "limit_try_m": None,
           "decision_doc": None, "exposure_try_m": None, "total_after_request_try_m": None,
           "unresolved_try_m": 0.0, "evidence": [], "facts": [], "explanation": ""}

    gid_company, name = resolve_company(company_query, party)
    if gid_company is None:
        out.update(decision="UNKNOWN_COMPANY",
                   explanation=f"No company matching '{company_query}' was found. Ask for the golden ID or the exact name.")
        return out
    out.update(golden_id=gid_company, company_name=name)

    rows = membership[membership["golden_id"] == gid_company]
    if len(rows) == 0:
        out.update(decision="CANNOT_CONFIRM", evidence=[POLICY_KEY],
                   explanation=f"{name} ({gid_company}) has no risk group on record; the group exposure cannot be established.")
        return out
    group_id = rows.iloc[0]["group_id"]
    out["group_id"] = group_id
    grp_members = membership[membership["group_id"] == group_id]
    out["group_name"] = data.get("group_names", {}).get(group_id, group_id)

    user = users[users["user_id"] == user_id]
    user_groups = set(split_list(user.iloc[0]["access_groups"])) if len(user) else set()
    if not (user_groups & allowed_groups_for(group_id)):
        out.update(decision="NOT_PERMITTED",
                   explanation=(f"User '{user_id}' may not see the limit and exposure of the risk group of {name}. "
                                "Refer the request to the group's relationship manager or Credit Risk."))
        return out

    names = dict(zip(party["golden_id"], party["name"]))
    out["members"] = [{"golden_id": r["golden_id"], "name": names.get(r["golden_id"], r["golden_id"]),
                       "reasons": r["reasons"], "evidence_ids": r["evidence_ids"]} for _, r in grp_members.iterrows()]
    out["facts"] = [f"{m['name']} ({m['golden_id']}): {m['reasons']} [{m['evidence_ids']}]" for m in out["members"]]

    in_force = decisions_in_force(documents, group_id, as_of, rules)
    if len(in_force) == 0:
        out.update(decision="CANNOT_CONFIRM", evidence=[POLICY_KEY],
                   explanation=f"No committee decision sets a group limit for {group_id} on {as_of.isoformat()}.")
        return out
    if len(in_force) > 1 and str(rules.get("multiple_decisions_policy", "")).lower() == "cannot_confirm":
        keys = list(in_force["doc_key"])
        out.update(decision="CANNOT_CONFIRM", evidence=[POLICY_KEY] + keys,
                   explanation=(f"More than one decision appears to be in force for {group_id} ({', '.join(keys)}). "
                                "Refer to Credit Risk before any recommendation (policy §4.6)."))
        return out
    decision_row = in_force.iloc[-1]  # naive fallback: latest valid_from
    limit = float(decision_row["limit_try_m"])
    out.update(limit_try_m=limit, decision_doc=decision_row["doc_key"])

    members = set(grp_members["golden_id"])
    active = loans[(loans["status"] == "active") & (loans["borrower_id"].isin(members))]
    exposure = float(active["exposure_try_m"].sum())
    total = exposure + amount
    out.update(exposure_try_m=exposure, total_after_request_try_m=total)

    pend = candidates[(candidates["status"] == "pending") & (candidates["candidate_golden_id"].isin(members))]
    unresolved_loans = loans[(loans["status"] == "active") & (loans["customer_no"].isin(pend["customer_no"]))
                             & (loans["borrower_id"].isna() | (loans["borrower_id"].astype(str) == ""))]
    unresolved = float(unresolved_loans["exposure_try_m"].sum())
    out["unresolved_try_m"] = unresolved

    base_evidence = [decision_row["doc_key"], POLICY_KEY, AUTHORITY_KEY]
    if total > limit:
        out.update(decision="PROPOSAL_REQUIRED", evidence=base_evidence + [PROPOSAL_PROCEDURE_KEY],
                   explanation=(f"Group exposure {fmt_m(exposure)} + requested {fmt_m(amount)} = {fmt_m(total)}, "
                                f"above the {fmt_m(limit)} limit in {decision_row['doc_key']}. The agent may not approve; "
                                "prepare a limit-increase proposal for the credit committee."))
        return out
    if unresolved > 0 and str(rules.get("unresolved_loan_policy", "")).lower() == "cannot_confirm_if_could_exceed" \
            and total + unresolved > limit:
        ids = ", ".join(unresolved_loans["loan_id"])
        out.update(decision="CANNOT_CONFIRM", evidence=base_evidence + [IDENTITY_PROCEDURE_KEY],
                   explanation=(f"Known group exposure {fmt_m(exposure)} + requested {fmt_m(amount)} = {fmt_m(total)}, "
                                f"within {fmt_m(limit)}; but unresolved loan(s) {ids} ({fmt_m(unresolved)}) may belong to the "
                                f"group and would take it to {fmt_m(total + unresolved)}. Resolve the borrower first."))
        return out
    out.update(decision="WITHIN_LIMIT", evidence=base_evidence,
               explanation=(f"Group exposure {fmt_m(exposure)} + requested {fmt_m(amount)} = {fmt_m(total)}, within the "
                            f"{fmt_m(limit)} limit in {decision_row['doc_key']}. The agent may recommend; the authorised "
                            "credit officer decides."))
    return out


# --------------------------------------------------------------------------------------
# Group facts (graph question) and watchlist scores (model question)
# --------------------------------------------------------------------------------------
def group_facts(company_query: str, user_id: str, data: dict) -> dict:
    party, membership, users = data["party"], data["membership"], data["users"]
    gid_company, name = resolve_company(company_query, party)
    if gid_company is None:
        return {"status": "UNKNOWN_COMPANY", "message": f"No company matching '{company_query}'."}
    user = users[users["user_id"] == user_id]
    user_groups = set(split_list(user.iloc[0]["access_groups"])) if len(user) else set()
    if not (user_groups & STAFF_GROUPS_ALLOWED_TO_SEE_STRUCTURE) and not (user_groups & {g for g in user_groups if g.startswith("rm-")}):
        return {"status": "NOT_PERMITTED", "message": f"User '{user_id}' may not see group structures."}
    rows = membership[membership["golden_id"] == gid_company]
    if len(rows) == 0:
        return {"status": "NO_GROUP", "golden_id": gid_company, "name": name, "members": []}
    group_id = rows.iloc[0]["group_id"]
    names = dict(zip(party["golden_id"], party["name"]))
    members = membership[membership["group_id"] == group_id].sort_values(["depth_from_head", "golden_id"])
    return {"status": "OK", "golden_id": gid_company, "name": name, "group_id": group_id,
            "group_name": data.get("group_names", {}).get(group_id, group_id),
            "members": [{"golden_id": r["golden_id"], "name": names.get(r["golden_id"]), "reasons": r["reasons"],
                         "depth_from_head": int(r["depth_from_head"]), "evidence_ids": r["evidence_ids"]}
                        for _, r in members.iterrows()],
            "rule": "Teaching version of Banking Law 5411 art. 49: head + every company it controls (directly or "
                    "through a company it controls), manages or guarantees.",
            "computed_for_date": rows.iloc[0]["computed_for_date"]}


def watchlist_scores(company_query: str, user_id: str, data: dict, top_n: int = 3) -> dict:
    """Top loans of the company's risk group by early-warning probability (scored dataset)."""
    party, membership, users, scores = data["party"], data["membership"], data["users"], data["loan_scores"]
    gid_company, name = resolve_company(company_query, party)
    if gid_company is None:
        return {"status": "UNKNOWN_COMPANY", "message": f"No company matching '{company_query}'."}
    rows = membership[membership["golden_id"] == gid_company]
    if len(rows) == 0:
        return {"status": "NO_GROUP", "golden_id": gid_company}
    group_id = rows.iloc[0]["group_id"]
    user = users[users["user_id"] == user_id]
    user_groups = set(split_list(user.iloc[0]["access_groups"])) if len(user) else set()
    if not (user_groups & allowed_groups_for(group_id)):
        return {"status": "NOT_PERMITTED", "message": f"User '{user_id}' may not see scores for {group_id}."}
    proba_col = "proba_1" if "proba_1" in scores.columns else [c for c in scores.columns if c.startswith("proba")][-1]
    members = set(membership[membership["group_id"] == group_id]["golden_id"])
    s = scores[scores["borrower_id"].isin(members)].sort_values(proba_col, ascending=False).head(top_n)
    return {"status": "OK", "group_id": group_id,
            "top_loans": [{"loan_id": r["loan_id"], "borrower_id": r["borrower_id"],
                           "watchlist_probability": round(float(r[proba_col]), 3)} for _, r in s.iterrows()],
            "note": "Model output informs the analyst; the credit rules and the authorised officer decide."}


def to_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str)
