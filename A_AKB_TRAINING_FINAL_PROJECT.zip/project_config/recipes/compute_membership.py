# Recipe: compute_membership  (Python recipe)
# Inputs : risk_group, ownership, management, guarantee, loan, rule_table
# Output : group_membership   (one row per company: group, reasons, depth, evidence ids)
#
# Why: the risk-group rule (teaching version of Banking Law 5411 art. 49) is applied once and
# the result is stored with its reasons, date and rule version: "precompute with provenance"
# (Module 21). Re-run it whenever ownership, management or guarantees change (Module 13).

import dataiku

import knowledge_rules as kr

AS_OF = dataiku.get_custom_variables().get("as_of_date", "2026-11-16")


def read(name):
    return dataiku.Dataset(name).get_dataframe()


groups = read("risk_group")
ownership = read("ownership")
management = read("management")
guarantees = read("guarantee")
loans = read("loan")
rules = kr.load_rules(read("rule_table"))

for df in (ownership, management, guarantees):
    for c in ("valid_from", "valid_to"):
        df[c] = df[c].astype(str).replace({"nan": "", "NaT": "", "None": ""})

membership = kr.compute_membership(groups, ownership, management, guarantees, loans, rules, AS_OF)
dataiku.Dataset("group_membership").write_with_schema(membership)
