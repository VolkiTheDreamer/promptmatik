# Recipe: build_loan_features  (Python recipe)
# Inputs : loan, party, group_membership, guarantee, documents_metadata, loan_risk_attributes,
#          loan_outcomes, rule_table
# Output : loan_features   (one row per active, resolved loan; target column watchlist_12m)
#
# Baseline features : product, cash_noncash, exposure_try_m, tenor_months, days_past_due_max_12m,
#                     borrower_leverage, sector, segment
# Graph features    : group_size, depth_from_head, guarantees_received, group_headroom_ratio
#                     (rejected in the scaffold model; the advanced path switches them on)

import dataiku
import pandas as pd

import kb_pipeline as kp
import knowledge_rules as kr

AS_OF = dataiku.get_custom_variables().get("as_of_date", "2026-11-16")


def read(name):
    df = dataiku.Dataset(name).get_dataframe()
    for c in ("valid_from", "valid_to"):
        if c in df.columns:
            df[c] = df[c].astype(str).replace({"nan": "", "NaT": "", "None": ""})
    return df


documents = read("documents_metadata")
documents["limit_try_m"] = pd.to_numeric(documents["limit_try_m"], errors="coerce")
features = kp.build_loan_features(read("loan"), read("party"), read("group_membership"), read("guarantee"),
                                  documents, read("loan_risk_attributes"), read("loan_outcomes"),
                                  kr.load_rules(read("rule_table")), AS_OF)
dataiku.Dataset("loan_features").write_with_schema(features)
