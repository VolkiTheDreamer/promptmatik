# Recipe: prepare_documents  (Python recipe)
# Input  : managed folder  documents          (the 60 .md files from data/documents)
# Outputs: dataset         documents_metadata (one row per document: KB metadata + full text)
#          dataset         document_chunks    (one row per section: text + lineage + "searchable")
#
# Why: the metadata is the knowledge base (status, validity, owner, access). Decisions are
# read from documents_metadata by exact filters; only open, in-force chunks are meant for
# vector search (Modules 02, 05, 06, 21).

import dataiku
import pandas as pd

import kb_pipeline as kp

AS_OF = dataiku.get_custom_variables().get("as_of_date", "2026-11-16")

folder = dataiku.Folder("documents")          # folder name or id
metas, chunks = [], []
for path in sorted(folder.list_paths_in_partition()):
    if not path.lower().endswith(".md"):
        continue
    with folder.get_download_stream(path) as stream:
        text = stream.read().decode("utf-8")
    meta = kp.parse_markdown_document(text, path)
    metas.append(meta)
    chunks.extend(kp.chunk_document(meta, AS_OF))

meta_df = pd.DataFrame(metas)
meta_df["limit_try_m"] = pd.to_numeric(meta_df["limit_try_m"], errors="coerce")
dataiku.Dataset("documents_metadata").write_with_schema(meta_df)
dataiku.Dataset("document_chunks").write_with_schema(pd.DataFrame(chunks))
