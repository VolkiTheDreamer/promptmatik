# Recipe: write_rule_table  (Python recipe, no input)
# Output: rule_table
#
# The business rules the check_request tool and compute_membership read on every call.
# Three rules are still blank (task R3). Read credit policy POL-CR-04 sections 4.5 and 4.6,
# fill in rule_value below, run this recipe, then re-test check_request.

import dataiku
import pandas as pd

RULES = [
    # rule_key, rule_value, description
    ("membership_include_control", "true", "Count companies the head controls, directly or through a controlled company"),
    ("membership_include_management", "true", "Count companies the head manages"),
    ("membership_include_guarantee", "true", "Count companies whose loans the head guarantees"),
    ("decision_validity_check", "dates", "How to decide which committee decision is in force: 'dates' = status AND valid_from/valid_to"),
    ("multiple_decisions_policy", "cannot_confirm", "If more than one decision is in force for a group: 'cannot_confirm'"),
    ("unresolved_loan_policy", "cannot_confirm_if_could_exceed", "If unresolved loans could take the group above its limit: 'cannot_confirm_if_could_exceed'"),
]

df = pd.DataFrame(RULES, columns=["rule_key", "rule_value", "description"]).astype(str)
dataiku.Dataset("rule_table").write_with_schema(df)
