# Recipe: evaluate_deterministic  (Python recipe)
# Inputs : golden_records          (the visible golden records)
#          agent_answers           (output of the Prompt recipe that runs the agent on golden_records)
# Outputs: eval_deterministic      (one row per record: decision, evidence, leak, numbers, passed)
#          eval_summary            (one row: pass rate, decision accuracy, evidence recall, leaks)
#
# Why: an LLM judge can rate a fluent answer with the wrong limit as "relevant". These checks
# are exact: the decision label, the evidence IDs, no restricted document for this user, and
# the key numbers. Run them next to the Evaluate Agent recipe (LLM-as-a-judge).
#
# If your Prompt recipe's output column is not "llm_output", change ANSWER_COL.

import dataiku

import kb_pipeline as kp

ANSWER_COL = "llm_output"

golden = dataiku.Dataset("golden_records").get_dataframe().fillna("")
answers = dataiku.Dataset("agent_answers").get_dataframe()
scores, summary = kp.score_answers(golden, answers, answer_col=ANSWER_COL)
dataiku.Dataset("eval_deterministic").write_with_schema(scores)
dataiku.Dataset("eval_summary").write_with_schema(summary)
