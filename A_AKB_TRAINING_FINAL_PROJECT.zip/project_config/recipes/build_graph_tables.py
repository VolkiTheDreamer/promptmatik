# Recipe: build_graph_tables  (Python recipe)
# Inputs : party, risk_group, ownership, guarantee, loan, group_membership
# Outputs: nodes_company, nodes_group, edges_controls, edges_guarantees, edges_member_of
#
# Why: node and edge datasets that Visual Graph (node/edge groups) or the Neo4j plugin
# (Export nodes / Export relationships, as in Labs 15-19) can load directly.
# Only relationships valid on the project's as_of_date are exported.

import dataiku

import kb_pipeline as kp

AS_OF = dataiku.get_custom_variables().get("as_of_date", "2026-11-16")


def read(name):
    df = dataiku.Dataset(name).get_dataframe()
    for c in ("valid_from", "valid_to"):
        if c in df.columns:
            df[c] = df[c].astype(str).replace({"nan": "", "NaT": "", "None": ""})
    return df


tables = kp.build_graph_tables(read("party"), read("risk_group"), read("ownership"), read("guarantee"),
                               read("loan"), read("group_membership"), AS_OF)
for name, df in tables.items():
    dataiku.Dataset(name).write_with_schema(df)
