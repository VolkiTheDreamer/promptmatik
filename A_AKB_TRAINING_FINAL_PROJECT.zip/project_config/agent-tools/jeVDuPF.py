# Agent tool: check_request   (GenAI > Agent Tools > New agent tool > Inline Python)
#
# Paste this whole file as the tool's code. If the template DSS shows you differs slightly
# (class name, import path), keep the template's skeleton and paste only the bodies of
# get_descriptor() and invoke(). All logic lives in the project library (knowledge_rules.py),
# which is tested offline.
#
# What it does: decides whether a new loan request fits the risk group's limit in force,
# with reasons, numbers and evidence IDs. The LLM explains this result; it never decides.

from dataiku.llm.agent_tools import BaseAgentTool

import kb_data
import knowledge_rules as kr


class CheckRequestTool(BaseAgentTool):

    def set_config(self, config, plugin_config):
        self.config = config

    def get_descriptor(self, tool):
        return {
            "description": (
                "Decides whether a NEW LOAN REQUEST for a company fits its risk group's credit limit on a date. "
                "Use it for every question like 'Can we give <company> a new <amount> loan?'. "
                "Returns a decision label (PROPOSAL_REQUIRED, WITHIN_LIMIT, CANNOT_CONFIRM, NOT_PERMITTED, "
                "UNKNOWN_COMPANY), the group, its members with reasons, the limit in force, exposure, totals, "
                "an explanation and the evidence document keys to cite. Amounts are in TRY millions."
            ),
            "inputSchema": {
                "$id": "check_request",
                "title": "Check a loan request against the group limit",
                "type": "object",
                "properties": {
                    "company": {"type": "string", "description": "Company name or golden ID exactly as the user wrote it"},
                    "amount_try_m": {"type": "number", "description": "Requested amount in TRY millions (e.g. 300 for TRY 300 M)"},
                    "user_id": {"type": "string", "description": "The requesting user's id from the 'Requesting user' line"},
                    "as_of": {"type": "string", "description": "Date YYYY-MM-DD from the 'Date' line"},
                },
                "required": ["company", "amount_try_m", "user_id"],
            },
        }

    def invoke(self, input, trace):
        args = input.get("input", {})
        data, rules = kb_data.load()
        result = kr.check_request(
            company_query=args.get("company", ""),
            amount_try_m=float(args.get("amount_try_m", 0)),
            as_of=args.get("as_of") or kb_data.as_of_default(),
            user_id=args.get("user_id", ""),
            data=data,
            rules=rules,
        )
        return {"output": kr.to_json(result)}
