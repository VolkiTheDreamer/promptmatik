# Agent tool: get_group_facts   (GenAI > Agent Tools > New agent tool > Inline Python)
#
# Paste as the tool's code (see the note in tool_check_request.py about the template).
# What it does: returns a company's risk group and every member with the reason it is in
# (head, control, control via X, management, guarantee GL-n) and the evidence row ids.
# This is the graph question; the answer comes from the precomputed group_membership dataset.

from dataiku.llm.agent_tools import BaseAgentTool

import kb_data
import knowledge_rules as kr


class GetGroupFactsTool(BaseAgentTool):

    def set_config(self, config, plugin_config):
        self.config = config

    def get_descriptor(self, tool):
        return {
            "description": (
                "Returns the risk group of a company and all members with the reason each is a member "
                "(head, control, control via another member, management, guarantee) and evidence ids. "
                "Use it for questions like 'Which group is X in?' or 'Who is in X's risk group and why?'. "
                "Does not return limits or exposures."
            ),
            "inputSchema": {
                "$id": "get_group_facts",
                "title": "Risk-group membership with reasons",
                "type": "object",
                "properties": {
                    "company": {"type": "string", "description": "Company name or golden ID"},
                    "user_id": {"type": "string", "description": "The requesting user's id from the 'Requesting user' line"},
                },
                "required": ["company", "user_id"],
            },
        }

    def invoke(self, input, trace):
        args = input.get("input", {})
        data, _ = kb_data.load()
        result = kr.group_facts(args.get("company", ""), args.get("user_id", ""), data)
        return {"output": kr.to_json(result)}
