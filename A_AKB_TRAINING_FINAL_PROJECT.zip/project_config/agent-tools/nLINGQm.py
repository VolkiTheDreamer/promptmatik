# Agent tool: get_watchlist_scores   (GenAI > Agent Tools > New agent tool > Inline Python)
#
# Paste as the tool's code (see the note in tool_check_request.py about the template).
# What it does: returns the loans of a company's risk group with the highest early-warning
# probability, from the scored dataset loan_scores (Score recipe output of the model).
# The model informs; the credit rules and the authorised officer decide.

from dataiku.llm.agent_tools import BaseAgentTool

import kb_data
import knowledge_rules as kr


class GetWatchlistScoresTool(BaseAgentTool):

    def set_config(self, config, plugin_config):
        self.config = config

    def get_descriptor(self, tool):
        return {
            "description": (
                "Returns the loans in a company's risk group with the highest predicted probability of being "
                "placed on the watchlist within 12 months (early-warning model). Use it only when the user asks "
                "about risk scores, early warning or watchlist. Never use it to decide a loan request."
            ),
            "inputSchema": {
                "$id": "get_watchlist_scores",
                "title": "Early-warning scores for a risk group",
                "type": "object",
                "properties": {
                    "company": {"type": "string", "description": "Company name or golden ID"},
                    "user_id": {"type": "string", "description": "The requesting user's id from the 'Requesting user' line"},
                    "top_n": {"type": "integer", "description": "How many loans to return (default 3)"},
                },
                "required": ["company", "user_id"],
            },
        }

    def invoke(self, input, trace):
        args = input.get("input", {})
        data, _ = kb_data.load(include_scores=True)
        if data.get("loan_scores") is None:
            return {"output": kr.to_json({"status": "NO_SCORES", "message": "Score the model first (loan_scores)."})}
        result = kr.watchlist_scores(args.get("company", ""), args.get("user_id", ""), data,
                                     int(args.get("top_n", 3) or 3))
        return {"output": kr.to_json(result)}
