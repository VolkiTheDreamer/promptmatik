import io
import json
import dataiku
import pandas as pd
import numpy as np

folder = dataiku.Folder("27W9mtRD")

def read_table(path):
    with folder.get_download_stream(path) as stream:
        df = pd.read_parquet(io.BytesIO(stream.read()))

    for column in df.columns:
        if df[column].dtype == object:
            df[column] = df[column].map(
                lambda value: json.dumps(
                    value.tolist() if isinstance(value, np.ndarray) else value,
                    ensure_ascii=False
                ) if isinstance(value, (list, dict, np.ndarray)) else value
            )

    return df

entities = read_table("output/create_final_entities.parquet")
relationships = read_table("output/create_final_relationships.parquet")

dataiku.Dataset("tolga_graphrag_entities").write_with_schema(entities)
dataiku.Dataset("tolga_graphrag_relationships").write_with_schema(relationships)

print("Entities:", len(entities), entities.columns.tolist())
print("Relationships:", len(relationships), relationships.columns.tolist())